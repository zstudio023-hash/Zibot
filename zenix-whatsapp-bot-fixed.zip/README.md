# Zenix WhatsApp Bot — Railway-ready project

## Important
Baileys is an unofficial WhatsApp Web integration. Use it only with accounts and groups you are authorized to manage. Avoid spam or unsolicited bulk messages. WhatsApp may change its protocol or restrict accounts using unofficial automation.

This project must run as a persistent Node.js worker/service, not as a static website. The WhatsApp session is stored in `auth_info_baileys/`; keep it private and use persistent storage where your host supports it.

## Deploy on Railway
1. Extract this ZIP.
2. Upload the **contents** of `zenix-whatsapp-bot-fixed` to a GitHub repository. `package.json` and `nixpacks.toml` must be in the repository root.
3. Connect that repository to a Railway service.
4. Railway should detect Node.js from `package.json`; `nixpacks.toml` and `railway.json` specify Node.js and `npm start`.
5. In Railway Variables, add `BOT_NAME=Zenix Bot`, `PREFIX=.`, and `OWNER_NUMBER` set to your own number in international format, digits only (example format `2637XXXXXXXX`).
6. Deploy and inspect logs for the QR code.
7. On WhatsApp, go to Settings > Linked devices > Link a device and scan the QR in logs.

If Railway still reports `Script start.sh not found`, check that `package.json` and `nixpacks.toml` are at the GitHub repository root. If they are in a nested folder, set Railway's Root Directory to that folder or move the files to the root.

## Run in Termux
Install Node.js 20+, extract the project, then run:
```sh
npm install
cp .env.example .env
nano .env
npm start
```

## Commands
.menu, .alive, .ping, .owner, .time, .date, .joke, .quote, .ai <question>, .autoreply on/off, .groupinfo, .tagall [message], .kick @member, .promote @member, .demote @member, .warn [message].

AI replies require `OPENAI_API_KEY`. Owner-only settings require `OWNER_NUMBER`. Group moderation requires suitable admin rights; the bot itself must be a group admin to remove/promote/demote participants.
