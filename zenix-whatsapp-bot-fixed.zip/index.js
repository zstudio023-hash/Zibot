require("dotenv").config();
const baileys = require("@whiskeysockets/baileys");
const makeWASocket = baileys.default;
const { jidNormalizedUser } = baileys;
const pino = require("pino");
const fs = require("fs");
const path = require("path");

const BOT_NAME = process.env.BOT_NAME || "Zenix Bot";
const PREFIX = process.env.PREFIX || ".";
const OWNER_NUMBER = (process.env.OWNER_NUMBER || "").replace(/\D/g, "");
const AUTH_DIR = path.join(__dirname, "auth_info_baileys");
const DATA_DIR = path.join(__dirname, "data");
const SETTINGS_FILE = path.join(DATA_DIR, "settings.json");
const logger = pino({ level: process.env.LOG_LEVEL || "silent" });
const seen = new Set(), spam = new Map(), metadataCache = new Map();
let sock, stopping = false;

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(SETTINGS_FILE)) fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ autoReply: process.env.AUTO_REPLY !== "false" }, null, 2));
const enabled = key => process.env[key] !== "false";
const filteredWords = (process.env.FILTERED_WORDS || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean);
const num = jid => String(jid || "").split("@")[0].split(":")[0].replace(/\D/g, "");
const isGroup = jid => String(jid || "").endsWith("@g.us");
const owner = jid => Boolean(OWNER_NUMBER) && num(jid) === OWNER_NUMBER;

function textOf(msg) {
  let m = msg?.message || {};
  for (let i = 0; i < 4; i++) {
    const inner = m.ephemeralMessage?.message || m.viewOnceMessage?.message || m.viewOnceMessageV2?.message || m.documentWithCaptionMessage?.message;
    if (!inner) break;
    m = inner;
  }
  return (m.conversation || m.extendedTextMessage?.text || m.imageMessage?.caption || m.videoMessage?.caption || m.documentMessage?.caption || "").trim();
}
function loadSettings() {
  try { return JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf8")); } catch { return { autoReply: enabled("AUTO_REPLY") }; }
}
function saveSettings(v) { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(v, null, 2)); }
async function reply(jid, text, quoted) { return sock.sendMessage(jid, { text }, quoted ? { quoted } : {}); }
async function metadata(jid) {
  const old = metadataCache.get(jid);
  if (old && Date.now() - old.time < 60000) return old.value;
  const value = await sock.groupMetadata(jid);
  metadataCache.set(jid, { value, time: Date.now() });
  return value;
}
async function admin(jid, who) {
  try {
    const p = (await metadata(jid)).participants.find(x => jidNormalizedUser(x.id) === jidNormalizedUser(who));
    return p?.admin === "admin" || p?.admin === "superadmin";
  } catch { return false; }
}
async function botAdmin(jid) {
  try {
    const me = jidNormalizedUser(sock.user.id);
    const p = (await metadata(jid)).participants.find(x => jidNormalizedUser(x.id) === me);
    return p?.admin === "admin" || p?.admin === "superadmin";
  } catch { return false; }
}
const menu = () => `╭━━〔 ${BOT_NAME} 〕━━╮
${PREFIX}menu — commands
${PREFIX}alive — bot status
${PREFIX}ping — response test
${PREFIX}owner — owner info
${PREFIX}time — Zimbabwe time
${PREFIX}date — date
${PREFIX}joke — random joke
${PREFIX}quote — motivation
${PREFIX}ai <question> — optional AI
${PREFIX}autoreply on/off — owner only
${PREFIX}groupinfo — group details
${PREFIX}tagall [message] — group admins
${PREFIX}kick @member — group admins
${PREFIX}promote @member — group admins
${PREFIX}demote @member — group admins
${PREFIX}warn [message] — group admins
╰━━━━━━━━━━━━━━╯`;
async function ai(prompt) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return "AI is not configured. Set OPENAI_API_KEY in Railway Variables.";
  const r = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4o-mini", messages: [
      { role: "system", content: "You are a concise, helpful WhatsApp assistant." },
      { role: "user", content: prompt.slice(0, 3000) }
    ], max_tokens: 500 })
  });
  if (!r.ok) { console.error("AI request failed:", r.status); return "AI is temporarily unavailable. Check your API settings."; }
  const data = await r.json();
  return data.choices?.[0]?.message?.content?.trim() || "No answer was generated.";
}
function mentioned(msg) { return msg?.message?.extendedTextMessage?.contextInfo?.mentionedJid || []; }

async function commandHandler(msg, commandText, chat, sender) {
  const [raw, ...args] = commandText.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (raw || "").toLowerCase(), arg = args.join(" "), group = isGroup(chat);
  switch (cmd) {
    case "menu": case "help": return reply(chat, menu(), msg);
    case "alive": return reply(chat, `✅ ${BOT_NAME} is online.\nUptime: ${Math.floor(process.uptime())} seconds`, msg);
    case "ping": return reply(chat, "🏓 Pong!", msg);
    case "owner": return reply(chat, OWNER_NUMBER ? `👑 Owner: https://wa.me/${OWNER_NUMBER}` : "Set OWNER_NUMBER in Railway Variables.", msg);
    case "time": return reply(chat, `🕒 ${new Date().toLocaleTimeString("en-GB", { timeZone: "Africa/Harare" })} (Zimbabwe time)`, msg);
    case "date": return reply(chat, `📅 ${new Date().toLocaleDateString("en-GB", { timeZone: "Africa/Harare", dateStyle: "full" })}`, msg);
    case "joke": return reply(chat, ["Why did the computer visit a doctor? It had a virus.", "I told my Wi-Fi we needed space. It disconnected.", "Why was the phone wearing glasses? It lost its contacts."][Math.floor(Math.random() * 3)], msg);
    case "quote": return reply(chat, ["Small steps every day lead to big results.", "Consistency beats motivation.", "Learn, build, improve, repeat."][Math.floor(Math.random() * 3)], msg);
    case "ai":
      if (!arg) return reply(chat, `Usage: ${PREFIX}ai ask a question`, msg);
      await reply(chat, "🧠 Thinking…", msg); return reply(chat, await ai(arg), msg);
    case "autoreply": {
      if (!owner(sender)) return reply(chat, "Only the configured owner can change this setting.", msg);
      const v = (args[0] || "").toLowerCase();
      if (!["on", "off"].includes(v)) return reply(chat, `Usage: ${PREFIX}autoreply on/off`, msg);
      const s = loadSettings(); s.autoReply = v === "on"; saveSettings(s); return reply(chat, `Auto-replies ${v}.`, msg);
    }
    case "groupinfo": {
      if (!group) return reply(chat, "This command only works in groups.", msg);
      const m = await metadata(chat);
      return reply(chat, `📋 ${m.subject}\nMembers: ${m.participants.length}\nAdmins: ${m.participants.filter(p => p.admin).length}`, msg);
    }
    case "tagall": {
      if (!group) return reply(chat, "This command only works in groups.", msg);
      if (!owner(sender) && !(await admin(chat, sender))) return reply(chat, "Only group admins or bot owner can use this.", msg);
      const ids = (await metadata(chat)).participants.map(p => p.id);
      return sock.sendMessage(chat, { text: `${arg || "Attention everyone!"}\n${ids.map(id => `• @${num(id)}`).join("\n")}`, mentions: ids }, { quoted: msg });
    }
    case "kick": case "promote": case "demote": {
      if (!group) return reply(chat, "This command only works in groups.", msg);
      if (!owner(sender) && !(await admin(chat, sender))) return reply(chat, "Only group admins or bot owner can use this.", msg);
      if (!(await botAdmin(chat))) return reply(chat, "Make the bot a group admin first.", msg);
      const ids = mentioned(msg);
      if (!ids.length) return reply(chat, `Mention a member: ${PREFIX}${cmd} @member`, msg);
      await sock.groupParticipantsUpdate(chat, ids, cmd === "kick" ? "remove" : cmd);
      metadataCache.delete(chat); return reply(chat, `✅ ${cmd} completed.`, msg);
    }
    case "warn":
      if (!group) return reply(chat, "This command only works in groups.", msg);
      if (!owner(sender) && !(await admin(chat, sender))) return reply(chat, "Only group admins or bot owner can use this.", msg);
      return reply(chat, `⚠️ ${arg || "Please follow the group rules."}`, msg);
    default: return null;
  }
}
async function onMessage(msg) {
  const key = msg.key || {}, chat = key.remoteJid, sender = key.participant || key.remoteJid;
  if (!chat || key.fromMe || chat === "status@broadcast" || chat.endsWith("@newsletter")) return;
  if (key.id && seen.has(key.id)) return;
  if (key.id) { seen.add(key.id); if (seen.size > 2500) seen.delete(seen.values().next().value); }
  const text = textOf(msg); if (!text) return;
  const group = isGroup(chat);
  if (group && enabled("WORD_FILTER") && filteredWords.length && !owner(sender) && filteredWords.some(w => text.toLowerCase().includes(w))) {
    if (await botAdmin(chat)) try { await sock.sendMessage(chat, { delete: key }); } catch (e) { console.error("Filter deletion failed:", e.message); }
    return;
  }
  if (group && enabled("ANTI_SPAM") && !owner(sender)) {
    const k = `${chat}:${sender}`, now = Date.now(), windowMs = Math.max(5, Number(process.env.SPAM_WINDOW_SECONDS || 10)) * 1000;
    const arr = (spam.get(k) || []).filter(t => now - t < windowMs); arr.push(now); spam.set(k, arr);
    if (arr.length >= Math.max(3, Number(process.env.SPAM_LIMIT || 6))) {
      spam.set(k, []); return reply(chat, `⚠️ @${num(sender)}, please slow down.`, msg);
    }
  }
  if (text.startsWith(PREFIX)) {
    try {
      const result = await commandHandler(msg, text, chat, sender);
      if (result !== null) return;
      return reply(chat, `Unknown command. Send ${PREFIX}menu.`, msg);
    } catch (e) { console.error("Command error:", e); return reply(chat, "Command failed. Check deployment logs.", msg); }
  }
  if (loadSettings().autoReply) {
    const t = text.toLowerCase();
    const replies = [
      [/^(hi|hello|hey|hie|mhoroi|salibonani)\b/, `👋 Hello! I'm ${BOT_NAME}. Send ${PREFIX}menu for commands.`],
      [/^good morning\b/, "🌞 Good morning! Hope you have a great day."],
      [/^good afternoon\b/, "☀️ Good afternoon! How can I help?"],
      [/^good evening\b/, "🌙 Good evening! How can I help?"],
      [/^(thanks|thank you|ndatenda)\b/, "😊 You're welcome!"]
    ];
    const match = replies.find(([re]) => re.test(t)); if (match) return reply(chat, match[1], msg);
  }
}
async function start() {
  const { state, saveCreds } = await baileys.useMultiFileAuthState(AUTH_DIR);
  let version; try { version = (await baileys.fetchLatestBaileysVersion()).version; } catch {}
  sock = makeWASocket({ ...(version ? { version } : {}), auth: state, logger,
    browser: ["Zenix Bot", "Chrome", "1.0.0"], markOnlineOnConnect: false,
    syncFullHistory: false, shouldSyncHistoryMessage: () => false });
  sock.ev.on("creds.update", saveCreds);
  sock.ev.on("connection.update", update => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) { console.log("\nScan in WhatsApp > Linked devices > Link a device:\n"); require("qrcode-terminal").generate(qr, { small: true }); }
    if (connection === "open") console.log(`✅ ${BOT_NAME} connected as ${sock.user?.id || "WhatsApp account"}`);
    if (connection === "close" && !stopping) {
      if (lastDisconnect?.error?.output?.statusCode === baileys.DisconnectReason.loggedOut) console.error("WhatsApp logged out. Remove saved auth folder and link again.");
      else { console.log("Connection closed; reconnecting shortly..."); setTimeout(() => start().catch(console.error), 3000); }
    }
  });
  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;
    for (const msg of messages) try { await onMessage(msg); } catch (e) { console.error("Message error:", e); }
  });
  sock.ev.on("group-participants.update", async u => {
    metadataCache.delete(u.id);
    if (!enabled("WELCOME_MESSAGES") || !["add", "invite"].includes(u.action)) return;
    try {
      const m = await metadata(u.id);
      for (const id of u.participants || []) await sock.sendMessage(u.id, {
        text: `👋 Welcome @${num(id)} to *${m.subject}*! Please read the group rules and enjoy your stay.`, mentions: [id]
      });
    } catch (e) { console.error("Welcome message error:", e.message); }
  });
}
process.on("SIGINT", () => { stopping = true; try { sock?.end?.(); } catch {} process.exit(0); });
process.on("SIGTERM", () => { stopping = true; try { sock?.end?.(); } catch {} process.exit(0); });
start().catch(e => { console.error("Bot startup failed:", e); process.exit(1); });
